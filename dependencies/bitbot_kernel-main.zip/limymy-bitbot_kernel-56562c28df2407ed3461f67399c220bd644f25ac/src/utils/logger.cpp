﻿#include "bitbot_kernel/utils/logger.h"
#include "spdlog/async.h"
#include "spdlog/sinks/stdout_color_sinks.h"
#include "spdlog/sinks/basic_file_sink.h"

#include <sstream>
#include <ctime>

namespace bitbot
{
  struct LoggerImpl 
  {
    LoggerImpl()
    {
      auto console_sink = std::make_shared<spdlog::sinks::stdout_color_sink_mt>();
      // console_sink->set_level(spdlog::level::trace);
      //console_sink->set_pattern("[%Y-%m-%d %H:%M:%S.%e] [%^%l%$] %v");
      console_sink->set_pattern("[%H:%M:%S.%e][%^%l%$] %v");

      console_logger = std::make_shared<spdlog::logger>(spdlog::logger("main_logger", { console_sink }));
      console_logger->set_level(spdlog::level::info);
      spdlog::register_logger(console_logger);
    }

    void SetConsoleLoggerLevel(spdlog::level::level_enum level)
    {
      console_logger->set_level(level);
    }

    SpdLoggerSharedPtr console_logger;
  };

  Logger::Logger() : impl_(impl()) {} // 构造函数直接初始化impl类

  SpdLoggerSharedPtr Logger::ConsoleLogger() 
  { 
    return impl_.console_logger;
  }

  void Logger::SetConsoleLoggerLevel(spdlog::level::level_enum level)
  {
    impl_.SetConsoleLoggerLevel(level);
  }

  LoggerImpl& Logger::impl() 
  {
    static LoggerImpl inst;
    return inst;
  }


}