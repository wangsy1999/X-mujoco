﻿#pragma once

#include "bitbot_kernel/kernel/kernel.hpp"
#include "bitbot_mujoco/bus/mujoco_bus.h"
#include "bitbot_mujoco/kernel/mujoco_utils.h"

#include "mujoco/mujoco.h"
#include "simulate.h"

#include <thread>

namespace bitbot
{
  // 将类成员函数转换为函数指针
  template <typename T, int tag = 0>
  struct Callback;
  template <typename Ret, typename... Params, int tag>
  struct Callback<Ret(Params...), tag> {
    template <typename... Args>
    static Ret callback(Args... args) {
        return func(args...);
    }
    int m_tag = tag;
    static std::function<Ret(Params...)> func;
  };
  template <typename Ret, typename... Params, int tag>
  std::function<Ret(Params...)> Callback<Ret(Params...), tag>::func;
  
  template <typename UserData, CompileTimeString... cts>
  class MujocoKernel : public KernelTpl<MujocoKernel<UserData, cts...>, MujocoBus, UserData, cts...>
  {
  public:
    MujocoKernel(std::string config_file)
      : KernelTpl<MujocoKernel<UserData, cts...>, MujocoBus, UserData, cts...>(config_file)
    {
      MujocoKernelInit();
    }
    ~MujocoKernel() = default;

  protected:
    void doStart()
    {
      sim_->run = 1;
    }

    void doRun()
    {
      // start physics thread
      std::thread physicsthreadhandle = std::thread(&MujocoKernel::PhysicsThread, this);

      // start simulation UI loop (blocking call)
      sim_->RenderLoop();
      physicsthreadhandle.join();
    
    };

    void MujocoConfigure(const pugi::xml_node& bitbot_node)
    {
      using namespace std::filesystem;

      auto mujoco_node = bitbot_node.child("mujoco");
      if(mujoco_node == NULL)
      {
        this->logger_->error("Config file need node: mujoco");
        return;
      }

      mujoco_file_ = mujoco_node.attribute("file").as_string();
      if(mujoco_file_.empty())
      {
        this->logger_->error("mujoco node does not have attribute \'file\'.");
      }
      else
      {
        path mujoco_file_path(mujoco_file_);
        if(mujoco_file_path.is_relative())
        {
          mujoco_file_path = canonical(this->parser_->FilePath().parent_path() / mujoco_file_path);
          mujoco_file_ = mujoco_file_path.string();
        }
      }
      this->logger_->debug("MuJoCo file: {}", mujoco_file_);

      // request loadmodel if file given (otherwise drag-and-drop)
      if (!mujoco_file_.empty()) {
        sim_->LoadMessage(sim_->dropfilename);
        mj_m_ = LoadModel(mujoco_file_.c_str(), *sim_);
        if (mj_m_) mj_d_ = mj_makeData(mj_m_);
        if (mj_d_) {
          // this->logger_->debug("mass: {}, CoM: {},{},{}", mj_m_->body_subtreemass[0], mj_d_->subtree_com[0], mj_d_->subtree_com[1], mj_d_->subtree_com[2]);
          // this->logger_->debug("nq: {} nv: {} nu: {} nbody: {} njnt: {}", mj_m_->nq, mj_m_->nv, mj_m_->nu, mj_m_->nbody, mj_m_->njnt);
          this->busmanager_.SetMujocoParam(mj_m_, mj_d_);
        }
      }
    }

    void PowerOn(int, KernelInterface&)
    {
      this->kernel_config_data_.power_on_finish_flag=true;
    }

  private:
    void MujocoKernelInit()
    {
      namespace mj = ::mujoco;

      // print version, check compatibility
      this->logger_->info("MuJoCo version {}", mj_versionString());
      if (mjVERSION_HEADER!=mj_version()) {
        this->logger_->error("MuJoCo headers and library have different versions");
      }

      // RegisterCmdCallback("power_on", std::bind(&MujocoKernel::PowerOn, this));

      // scan for libraries in the plugin directory to load additional plugins
      scanPluginLibraries();

      static mjvCamera cam;
      mjv_defaultCamera(&cam);

      static mjvOption opt;
      mjv_defaultOption(&opt);

      static mjvPerturb pert;
      mjv_defaultPerturb(&pert);

      // simulate object encapsulates the UI
      sim_ = std::make_unique<mj::Simulate>(
          std::make_unique<mj::GlfwAdapter>(),
          &cam, &opt, &pert, /* is_passive = */ false
      );
      sim_->run = 0;

      MujocoConfigure(this->parser_->GetBitbotNode());
    }

    void PhysicsThread()
    {
      if(mj_m_ && mj_d_)
      {
        sim_->Load(mj_m_, mj_d_, mujoco_file_.c_str());
        mj_forward(mj_m_, mj_d_);

        // allocate ctrlnoise
        free(mj_ctrlnoise_);
        mj_ctrlnoise_ = static_cast<mjtNum*>(malloc(sizeof(mjtNum)*mj_m_->nu));
        mju_zero(mj_ctrlnoise_, mj_m_->nu);

        this->busmanager_.UpdateDevices();
      }
      else
      {
        sim_->LoadMessageClear();
      }

      Callback<void(const mjModel*, mjData*)>::func = std::bind(&MujocoKernel::mjcbControl, this, std::placeholders::_1, std::placeholders::_2);
      mjcb_control = static_cast<mjfGeneric>(Callback<void(const mjModel*, mjData*)>::callback);

      PhysicsLoop();

      // delete everything we allocated
      free(mj_ctrlnoise_);
      mj_deleteData(mj_d_);
      mj_deleteModel(mj_m_);
    }

    void PhysicsLoop()
    {
      namespace mj = ::mujoco;
      using Seconds = std::chrono::duration<double>;

      // cpu-sim syncronization point
      std::chrono::time_point<mj::Simulate::Clock> syncCPU;      
      mjtNum syncSim = 0;

      // run until asked to exit
      while (!sim_->exitrequest.load()) {
        if (sim_->droploadrequest.load()) {
          sim_->LoadMessage(sim_->dropfilename);
          mjModel* mnew = LoadModel(sim_->dropfilename, *sim_);
          sim_->droploadrequest.store(false);

          mjData* dnew = nullptr;
          if (mnew) dnew = mj_makeData(mnew);
          if (dnew) {
            sim_->Load(mnew, dnew, sim_->dropfilename);

            mj_deleteData(mj_d_);
            mj_deleteModel(mj_m_);

            mj_m_ = mnew;
            mj_d_ = dnew;
            mj_forward(mj_m_, mj_d_);

            // allocate mj_ctrlnoise_
            free(mj_ctrlnoise_);
            mj_ctrlnoise_ = (mjtNum*) malloc(sizeof(mjtNum)*mj_m_->nu);
            mju_zero(mj_ctrlnoise_, mj_m_->nu);
          }
          else
          {
            sim_->LoadMessageClear();
          }
        }

        // ui reload
        if (sim_->uiloadrequest.load()) {
          sim_->uiloadrequest.fetch_sub(1);
          sim_->LoadMessage(sim_->dropfilename);
          mjModel* mnew = LoadModel(sim_->filename, *sim_);
          mjData* dnew = nullptr;
          if (mnew) dnew = mj_makeData(mnew);
          if (dnew) {
            sim_->Load(mnew, dnew, sim_->filename);

            mj_deleteData(mj_d_);
            mj_deleteModel(mj_m_);
            
            mj_m_ = mnew;
            mj_d_ = dnew;
            mj_forward(mj_m_, mj_d_);

            // allocate mj_ctrlnoise_
            free(mj_ctrlnoise_);
            mj_ctrlnoise_ = static_cast<mjtNum*>(malloc(sizeof(mjtNum)*mj_m_->nu));
            mju_zero(mj_ctrlnoise_, mj_m_->nu);
          }
          else
          {
            sim_->LoadMessageClear();
          }
        }

        // sleep for 1 ms or yield, to let main thread run
        //  yield results in busy wait - which has better timing but kills battery life
        if (sim_->run && sim_->busywait) {
          std::this_thread::yield();
        } else {
          std::this_thread::sleep_for(std::chrono::milliseconds(1));
        }

        {
          // lock the sim mutex
          const std::unique_lock<std::recursive_mutex> lock(sim_->mtx);

          // run only if model is present
          if (mj_m_) {
            // running
            if (sim_->run && !this->kernel_config_data_.stop_flag /*&& this->kernel_config_data_.power_on_finish_flag*/) {
            // if (sim_->run && !this->kernel_config_data_.stop_flag && this->kernel_config_data_.power_on_finish_flag) {
              bool stepped = false;
              // record cpu time at start of iteration
              const auto startCPU = mj::Simulate::Clock::now();

              // elapsed CPU and simulation time since last sync
              const auto elapsedCPU = startCPU - syncCPU;
              double elapsedSim = mj_d_->time - syncSim;

              // inject noise
              if (sim_->ctrl_noise_std) {
                // convert rate and scale to discrete time (Ornstein–Uhlenbeck)
                mjtNum rate = mju_exp(-mj_m_->opt.timestep / mju_max(sim_->ctrl_noise_rate, mjMINVAL));
                mjtNum scale = sim_->ctrl_noise_std * mju_sqrt(1-rate*rate);

                for (int i=0; i<mj_m_->nu; i++) {
                  // update noise
                  mj_ctrlnoise_[i] = rate * mj_ctrlnoise_[i] + scale * mju_standardNormal(nullptr);

                  // apply noise
                  mj_d_->ctrl[i] = mj_ctrlnoise_[i];
                }
              }

              // requested slow-down factor
              double slowdown = 100 / sim_->percentRealTime[sim_->real_time_index];

              // misalignment condition: distance from target sim time is bigger than syncmisalign
              bool misaligned = mju_abs(Seconds(elapsedCPU).count()/slowdown - elapsedSim) > syncMisalign;

              // out-of-sync (for any reason): reset sync times, step
              if (elapsedSim < 0 || elapsedCPU.count() < 0 || syncCPU.time_since_epoch().count() == 0 ||
                  misaligned || sim_->speed_changed) {                // re-sync
                syncCPU = startCPU;
                syncSim = mj_d_->time;
                sim_->speed_changed = false;

                // run single step, let next iteration deal with timing
                mj_step(mj_m_, mj_d_);
                stepped = true;
                this->KernelPrivateLoopEndTask();
              }

              // in-sync: step until ahead of cpu
              else {
                bool measured = false;
                mjtNum prevSim = mj_d_->time;
                double refreshTime = simRefreshFraction/sim_->refresh_rate;

                // step while sim lags behind cpu and within refreshTime
                while (Seconds((mj_d_->time - syncSim)*slowdown) < mj::Simulate::Clock::now() - syncCPU &&
                   mj::Simulate::Clock::now() - startCPU < Seconds(refreshTime)) {
                  // measure slowdown before first step
                  if (!measured && elapsedSim) {
                    sim_->measured_slowdown = std::chrono::duration<double>(elapsedCPU).count() / elapsedSim;;
                    measured = true;
                  }

                  // call mj_step
                  mj_step(mj_m_, mj_d_);
                  stepped = true;
                  this->KernelPrivateLoopEndTask();

                  // break if reset
                  if (mj_d_->time < prevSim) {
                    break;
                  }
                }
              }

              if (stepped) {
                sim_->AddToHistory();
              }
            }

            // paused
            else {
              // run mj_forward, to update rendering and joint sliders
              mj_forward(mj_m_, mj_d_);
              sim_->speed_changed = true;

              this->busmanager_.ReadBus();
              this->UpdateRuntimeData();
              this->backend_->SetMonitorData(this->monitor_data_);

              this->HandleEvents();
            }
          }
        }  // release std::lock_guard<std::mutex>
      }

    }

    void mjcbControl(const mjModel* m, mjData* d)
    {
      using namespace std::chrono;
      static auto timestep = m->opt.timestep;
      static uint64_t last_step = 0, this_step = 0;
      static double last_mjtime = 0, this_mjtime = 0;

      this_step = static_cast<uint64_t>(d->time/timestep);

      if(this_step > last_step)
      {
        auto start_time = std::chrono::high_resolution_clock::now();
        
        this_mjtime = d->time * 1e3;

        this->kernel_runtime_data_.periods_count++;
        this->kernel_runtime_data_.period = this_mjtime - last_mjtime;

        // this->logger_->debug("torque: act {} qfrc {}", d->actuator_force[0], d->qfrc_actuator[6]);

        this->HandleEvents();
        this->KernelLoopTask();

        last_mjtime = this_mjtime;

        auto end_time = std::chrono::high_resolution_clock::now();
        this->kernel_runtime_data_.process_time = duration_cast<nanoseconds>(end_time - start_time).count()/1e6;
      }

      last_step = this_step;
    }

    std::string mujoco_file_;

    std::unique_ptr<mujoco::Simulate> sim_ = nullptr;
    mjModel* mj_m_ = nullptr;
    mjData* mj_d_ = nullptr;
    // control noise variables
    mjtNum* mj_ctrlnoise_ = nullptr;

    double syncMisalign = 0.1;        // maximum mis-alignment before re-sync (simulation seconds)
    double simRefreshFraction = 0.7;  // fraction of refresh available for simulation

    std::unique_ptr<std::thread> physics_thread_;
  };
  

}
